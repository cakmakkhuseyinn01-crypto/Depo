# ONMYOTR Translate — Android ilk sürüm

Android ekranını MediaProjection ile yakalar, ML Kit OCR ile metni tanır, İngilizce-Türkçe ML Kit modeliyle çevirir ve yüzen panelde gösterir.

## Kurulum
1. ZIP'i aç ve klasörü Android Studio ile aç.
2. JDK 17 ve Android SDK 35 kurulu olsun.
3. Gradle senkronizasyonunu tamamla; telefonu USB ile bağlayıp Run'a bas.
4. Uygulamada üstte gösterme iznini ver.
5. Çeviriyi başlat ve Android ekran yakalama onayını kabul et.
6. Oyuna dön. İlk çeviride İngilizce-Türkçe modeli indirilebilir.

## Notlar
- Bu kaynak projedir; hazır APK değildir. Android Studio > Build > Build APK(s) ile APK üretilebilir.
- Ekran görüntüsü cihaz üzerinde OCR işleminden geçer; bu kod görüntüyü sunucuya yüklemez.
- Çeviri metni ekranın üstünde bir panelde gösterilir; oyunun kendi metnini değiştirmez.
- OCR küçük yazı, hareketli ekran ve efektlerde hata yapabilir.
- İlk model indirme için internet gerekir; model indirildikten sonra ML Kit çevirisi cihazda çalışabilir.
- Bazı uygulamalar ekran yakalamayı engelleyebilir. Android sürümü ve üreticiye göre izinler farklı görünebilir.
- Bu ilk prototip, oyuna özel karakter/eşya terim sözlüğü ve metin konumuna göre birebir kaplama içermez; bunlar sonraki sürümde eklenecek.
