package com.onmyotr.translate

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.*
import java.util.concurrent.atomic.AtomicBoolean

class OverlayTranslateService : Service() {
    companion object { const val CODE="result_code"; const val DATA="result_data"; private const val CHANNEL="onmyotr"; private const val ID=71 }
    private var projection: MediaProjection?=null
    private var display: VirtualDisplay?=null
    private var reader: ImageReader?=null
    private var thread: HandlerThread?=null
    private var handler: Handler?=null
    private var wm: WindowManager?=null
    private var panel: TextView?=null
    private var translator: Translator?=null
    private val busy=AtomicBoolean(false)
    private var lastText=""
    private var lastAt=0L

    override fun onCreate() {
        super.onCreate()
        val nm=getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(CHANNEL,"ONMYOTR Translate",NotificationManager.IMPORTANCE_LOW))
        startForeground(ID,NotificationCompat.Builder(this,CHANNEL).setContentTitle("ONMYOTR Translate çalışıyor").setContentText("Ekrandaki metinler çevriliyor").setSmallIcon(android.R.drawable.ic_menu_translate).setOngoing(true).build())
        thread=HandlerThread("OnmyoOCR").also{it.start()}; handler=Handler(thread!!.looper)
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        translator=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.TURKISH).build())
        translator?.downloadModelIfNeeded()
    }
    override fun onStartCommand(intent: Intent?,flags:Int,startId:Int):Int {
        @Suppress("DEPRECATION") val data=intent?.getParcelableExtra<Intent>(DATA)
        val code=intent?.getIntExtra(CODE,0) ?: 0
        if(data==null || code==0){stopSelf();return START_NOT_STICKY}
        try {
            val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection=mgr.getMediaProjection(code,data)
            projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},handler)
            startCapture()
            show("ONMYOTR hazır. İngilizce metin aranıyor…")
        } catch(e:Exception){show("Ekran yakalama başlatılamadı.");stopSelf()}
        return START_NOT_STICKY
    }
    private fun startCapture() {
        val m=resources.displayMetrics; val w=m.widthPixels; val h=m.heightPixels
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        reader!!.setOnImageAvailableListener({ r ->
            val img=r.acquireLatestImage() ?: return@setOnImageAvailableListener
            if(!busy.compareAndSet(false,true)){img.close();return@setOnImageAvailableListener}
            handler?.post { try{process(img)}finally{img.close();busy.set(false)} }
        },handler)
        display=projection?.createVirtualDisplay("ONMYOTR",w,h,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
    }
    private fun process(img:Image) {
        val p=img.planes[0]; val bmp=Bitmap.createBitmap(img.width,img.height,Bitmap.Config.ARGB_8888)
        val padded=Bitmap.createBitmap(img.width+(p.rowStride-p.pixelStride*img.width)/p.pixelStride,img.height,Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(p.buffer); val crop=Bitmap.createBitmap(padded,0,0,img.width,img.height); padded.recycle()
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(crop,0))
            .addOnSuccessListener { result ->
                val lines=result.textBlocks.flatMap{it.lines}.map{it.text.trim()}.filter{it.length in 3..100 && it.any(Char::isLetter)}.distinct().take(12)
                val text=lines.filter{it.any{c->c in 'a'..'z'||c in 'A'..'Z'} && !it.contains("ONMYOTR",true)}.joinToString("\n")
                if(text.isNotBlank() && text!=lastText){lastText=text; translate(text)}
            }.addOnFailureListener{show("Metin okunamadı; ekranı sabit tut.")}.addOnCompleteListener{crop.recycle();bmp.recycle()}
    }
    private fun translate(text:String) {
        if(System.currentTimeMillis()-lastAt<1000)return
        lastAt=System.currentTimeMillis()
        translator?.translate(text)?.addOnSuccessListener{show("ONMYOTR • TÜRKÇE\n"+it.lines().take(10).joinToString("\n"))}
            ?.addOnFailureListener{show("Çeviri modeli indiriliyor. İnternet bağlantısını kontrol et.")}
    }
    private fun show(text:String) {
        if(!Settings.canDrawOverlays(this))return
        val v=panel ?: TextView(this).also {
            it.textSize=14f;it.setTextColor(0xFFFFFFFF.toInt());it.setBackgroundColor(0xDD17131A.toInt());it.setPadding(20,14,20,14);it.maxLines=10
            val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP;y=32}
            wm?.addView(it,lp);panel=it
        }
        v.text=text
    }
    override fun onDestroy() {
        display?.release();reader?.close();projection?.stop()
        panel?.let{try{wm?.removeView(it)}catch(_:Exception){}}
        translator?.close();thread?.quitSafely();super.onDestroy()
    }
    override fun onBind(intent:Intent?)=null
}
