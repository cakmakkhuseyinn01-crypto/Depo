package com.onmyotr.translate

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val requestCode = 4102
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(p,p,p,p) }
        root.addView(TextView(this).apply { text = "ONMYOTR TRANSLATE"; textSize = 26f; setTextColor(0xFF9E1B26.toInt()) })
        root.addView(TextView(this).apply { text = "Oyun ekranındaki İngilizce metinleri algılar ve Türkçe karşılığını yüzen panelde gösterir. İlk kullanımda ekran yakalama ve diğer uygulamaların üzerinde gösterme izinleri gerekir."; textSize = 16f; setPadding(0,p,0,p) })
        root.addView(Button(this).apply { text = "1. Üstte gösterme iznini ver"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
        root.addView(Button(this).apply { text = "2. Çeviriyi başlat"; setOnClickListener { beginCapture() } })
        root.addView(Button(this).apply { text = "Çeviriyi durdur"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayTranslateService::class.java)) } })
        root.addView(TextView(this).apply { text = "Not: İlk kullanımda İngilizce-Türkçe dil modeli indirilebilir. Oyun dosyaları değiştirilmez; ekran görüntüleri cihaz üzerinde işlenir."; textSize = 13f; setPadding(0,p,0,0) })
        setContentView(root)
    }
    private fun beginCapture() {
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"Önce üstte gösterme iznini ver.",Toast.LENGTH_LONG).show(); return }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), requestCode)
    }
    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK && data != null) {
            val i = Intent(this,OverlayTranslateService::class.java).apply { putExtra(OverlayTranslateService.CODE,resultCode); putExtra(OverlayTranslateService.DATA,data) }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            Toast.makeText(this,"ONMYOTR çeviri başladı.",Toast.LENGTH_SHORT).show()
        }
    }
}
