plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.onmyotr.translate"
    compileSdk = 35
    defaultConfig { applicationId = "com.onmyotr.translate"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:translate:17.0.3")
}
